from django.contrib import admin
from django.urls import path, include
from rest_framework.permissions import AllowAny

from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularSwaggerView,
    SpectacularRedocView,
)

urlpatterns = [
    path('admin/', admin.site.urls),

    # JWT Authentication
    path(
        'api/token/',
        TokenObtainPairView.as_view(
            authentication_classes=[],
            permission_classes=[AllowAny],
        ),
        name='token_obtain_pair'
    ),

    path(
        'api/token/refresh/',
        TokenRefreshView.as_view(
            authentication_classes=[],
            permission_classes=[AllowAny],
        ),
        name='token_refresh'
    ),

    # OpenAPI Schema
    path(
        'api/schema/',
        SpectacularAPIView.as_view(),
        name='schema'
    ),

    path(
        'api/docs/',
        SpectacularSwaggerView.as_view(
            url_name='schema'
        ),
        name='swagger-ui'
    ),

    path(
        'api/redoc/',
        SpectacularRedocView.as_view(
            url_name='schema'
        ),
        name='redoc'
    ),

    path(
        'api/v1/schema/',
        SpectacularAPIView.as_view(api_version='v1'),
        name='schema-v1'
    ),

    path(
        'api/v1/docs/',
        SpectacularSwaggerView.as_view(
            url_name='schema-v1'
        ),
        name='swagger-ui-v1'
    ),

    path(
        'api/v2/schema/',
        SpectacularAPIView.as_view(api_version='v2'),
        name='schema-v2'
    ),

    path(
        'api/v2/docs/',
        SpectacularSwaggerView.as_view(
            url_name='schema-v2'
        ),
        name='swagger-ui-v2'
    ),

    # CRUD Pages and versioned student API
    path('', include('students.urls')),
]