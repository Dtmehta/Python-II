from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import render, redirect, get_object_or_404
from rest_framework import viewsets

from .models import Student
from .forms import StudentForm
from .permissions import IsAdminOrReadOnly
from .serializers import StudentSerializerV1, StudentSerializerV2


def is_admin(user):
    return user.is_staff


def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('student_list')
    else:
        form = UserCreationForm()

    return render(request, 'students/signup.html', {
        'form': form
    })


def user_login(request):
    if request.user.is_authenticated:
        return redirect('student_list')
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(
            request,
            username=username,
            password=password
        )
        if user is not None:
            login(request, user)
            return redirect('student_list')
    return render(request, 'students/login.html')


def user_logout(request):
    logout(request)
    return render(request, 'students/logout.html')


@login_required
def student_list(request):
    students = Student.objects.all()
    return render(request,
                  'students/student_list.html',
                  {'students': students})


@login_required
@user_passes_test(is_admin)
def student_create(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('student_list')
    else:
        form = StudentForm()
    return render(request,
                  'students/student_form.html',
                  {'form': form})


@login_required
@user_passes_test(is_admin)
def student_update(request, pk):
    student = get_object_or_404(Student, pk=pk)

    if request.method == 'POST':
        form = StudentForm(
            request.POST,
            instance=student
        )
        if form.is_valid():
            form.save()
            return redirect('student_list')
    else:
        form = StudentForm(instance=student)

    return render(request,
                  'students/student_form.html',
                  {'form': form})


@login_required
@user_passes_test(is_admin)
def student_delete(request, pk):
    student = get_object_or_404(Student, pk=pk)

    if request.method == 'POST':
        student.delete()
        return redirect('student_list')

    return render(request,
                  'students/student_confirm_delete.html',
                  {'student': student})


class StudentViewSet(viewsets.ModelViewSet):
    queryset = Student.objects.all()
    permission_classes = [IsAdminOrReadOnly]

    def get_serializer_class(self):
        if self.request.version == 'v2':
            return StudentSerializerV2

        return StudentSerializerV1