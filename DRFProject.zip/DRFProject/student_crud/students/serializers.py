from rest_framework import serializers
from .models import Student


class StudentSerializerV1(serializers.ModelSerializer):

    class Meta:
        model = Student
        fields = '__all__'


class StudentSerializerV2(serializers.ModelSerializer):

    student_info = serializers.SerializerMethodField()

    class Meta:
        model = Student
        fields = [
            'id',
            'name',
            'roll',
            'city',
            'student_info'
        ]

    def get_student_info(self, obj) -> str:
        return f"{obj.name} from {obj.city}"