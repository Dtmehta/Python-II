from django.shortcuts import render
from rest_framework import viewsets
from rest_framework.response import Response
from rest_framework.decorators import action,api_view,permission_classes
from rest_framework.permissions import IsAuthenticated,AllowAny
from .models import Student
from .serializers import StudentSerializer

class StudentViewSet(viewsets.ModelViewSet):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    permission_classes = [IsAuthenticated]

    @action(detail=False , methods=['get'])
    def total(self,request):
        count = Student.objects.all()
        return Response({"TotalStudents" : count})
    
@api_view(['GET'])
@permission_classes([AllowAny])
def welcome(request):
    return Response({"message" : "Welcome to DRF"})
