from rest_framework import serializers
from .models import Student

class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = "__all__"
        read_only_fields = ['id']
    def validate(self,data):
        if data['age'] < 18:
            raise serializers.ValidationError("Age must be over 18")
        return data