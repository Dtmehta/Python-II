from django.contrib import admin
from django.urls import path,include
from rest_framework.routers import DefaultRouter
from rest_framework_simplejwt.views import TokenObtainPairView , TokenRefreshView
from accounts.views import StudentViewSet,welcome

router = DefaultRouter()
router.register("students",StudentViewSet)

urlpatterns = [
    path("admin/" , admin.site.urls),
    path("",include(router.urls)),
    path("token/" , TokenObtainPairView.as_view()),
    path("token/refresh/" , TokenRefreshView.as_view()),
    path("welcome/",welcome),
]
