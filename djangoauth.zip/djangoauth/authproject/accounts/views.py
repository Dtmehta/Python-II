from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login,logout,authenticate
from django.contrib import messages

def home(request):
    return render(request,"accounts/home.html")

@login_required
def dashboard(request):
    return render(request , 'accounts/dashboard.html')

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request , user)
            return redirect('dashboard')
    else:
        form = UserCreationForm()
    return render(request , "accounts/signup.html" , {'form' : form})

def user_login(request):
    if request.user.is_authenticated:
        return redirect ('dashboard')
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request , username=username , password=password)
        if user is not None:
            login(request,user)
            messages.success(request,"Login Successful")
            return redirect('dashboard')
        else:
            messages.error(request,"Invalid creadentials")
    return render(request , "accounts/login.html")

def custom_logout(request):
    logout(request)
    return render (request , "accounts/logout.html")